
public class A300B extends Vehicule {
	public A300B(){
		super();
		this.nom = "A300B";
		this.nomMarque = Marque.PIGEOT;
	}
}
