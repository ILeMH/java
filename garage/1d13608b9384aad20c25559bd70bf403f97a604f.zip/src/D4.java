
public class D4 extends Vehicule {
	public D4(){
		super();
		this.nom = "D4";
		this.nomMarque = Marque.TROEN;
	}
}
