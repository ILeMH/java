
public class Lagouna extends Vehicule {
	public Lagouna(){
		super();
		this.nom = "Lagouna";
		this.nomMarque = Marque.RENO;
	}
}
