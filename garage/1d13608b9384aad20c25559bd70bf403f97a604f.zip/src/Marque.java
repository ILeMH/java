
public enum Marque {
	RENO("Reno"),
	PIGEOT("Pigeot"),
	TROEN("Troen");
	
	private String name = "";
   
	Marque(String name){
	   this.name = name;
	}
   
	public String toString(){
		return name;
	}
}
