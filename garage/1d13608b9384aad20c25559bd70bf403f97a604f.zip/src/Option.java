public interface Option {
	public Double getPrix();
	
}
